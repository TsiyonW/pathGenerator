class States:
       NORMAL = 'NORMAL'
       IN_COMMENT= 'IN_COMMENT'
       IN_STR_LITERAL = 'IN_STR_LITERAL'
       IN_CHAR_LITERAL = 'IN_CHAR_LITERAL'
       COMMENT_WAITING = 'COMMENT_WAITING'
       ESCAPE_STR = 'ESCAPE_STR'
       ESCAPE_CHAR = 'ESCAPE_CHAR'
       ESCAPE_WAITING = 'ESCAPE_WAITING'
       OUT_OF_COMMENT_WAITING = 'OUT_OF_COMMENT_WAITING'
       NOTHING = 'NOTHING'

def handleNormal(c,outfile):
    state = States.NOTHING
    if c == '\'':
        outfile.write(c)
        state = States.IN_CHAR_LITERAL
    elif c == '\"':
        outfile.write(c)
        state = States.IN_STR_LITERAL
    elif c == '/':
        state = States.COMMENT_WAITING
    elif c == '\\':
        outfile.write(c)
        state = States.ESCAPE_WAITING
    elif c == '\n':
        outfile.write(c)
        state = States.NORMAL
    else:
        outfile.write(c)
        state = States.NORMAL
    

    return state

def handleInComment(c,outfile):
    state = States.NOTHING
    if c == '*':
       state = States.OUT_OF_COMMENT_WAITING
       
    elif c == '\n':
        outfile.write(c)
        state = States.IN_COMMENT;
    else:
           outfile.write(" ")

    return state
def handleInStrLiteral(c,outfile):
    state = States.NOTHING
    if c == '\n':
        outfile.write(c)
        state = States.IN_STR_LITERAL
    if c == '\"':

        state = States.NORMAL
    if c == '\\':
        state = States.ESCAPE_STR
    outfile.write(c)
    return state
def handleInCharLiteral(c,outfile):
    state = States.NOTHING
    if c == '\n':
        state = States.IN_CHAR_LITERAL
        outfile.write(c)
    if c == '\'':
        state = States.NORMAL

    if c == '\\':
        state = States.ESCAPE_WAITING
    outfile.write(c)
    return state

def handleCommentWaiting(c,outfile):
    state = States.NOTHING
    if c == '*':
        outfile.write(" ")
        state = States.IN_COMMENT
    elif c== '/':
           outfile.write(" ")
           state  = States.IN_COMMENT
    
    else:
        outfile.write(c);
        state = States.NORMAL
        
    if c == '\n':
        outfile.write(c);

    return state

def handleDoubleQEC(c,outfile):
    state = States.NOTHING
    if c == '\'':
        outfile.write(c);           
        state = States.IN_STR_LITERAL
    elif c == '\"':
        outfile.write(c);           
        state = States.IN_STR_LITERAL
    state = IN_STR_LITERAL
    if c == '\n':
       state = States.ESCAPE_STR
       outfile.write(c);
       
    return state

def handleSingleQEC(c,outfile):
       state = States.NOTHING
       if c == '\'':
              outfile.write(c);
              state = States.IN_CHAR_LITERAL
       elif c == '\"':
              outfile.write(c);
              state = States.IN_CHAR_LITERAL
       state = IN_CHAR_LITERAL
       if c == '\n':
              outfile.write(c);
              state = States.ESCAPE_CHAR
       
       return state
def handleEscapeWaiting(c,outfile):
    state = States.NOTHING
    if c == '\'':
        outfile.write(c);
        state = States.NORMAL
    elif c == '\"':
        outfile.write(c);
        state = States.NORMAL
    
    state = States.ESCAPE_WAITING
    if c == '\n':
       outfile.write(c);
       state = States.ESCAPE_WAITING
    
    return state

def handleOOCW(c):
       state = States.NOTHING
       if c =='/':
              state = States.NORMAL
              unterminated = 1
       else:
              state = States.IN_COMMENT
       return state
    
def caller(file):
       array = []
       infile = open(file,"r")
       file2 = "Decommented_"+file
       outfile = open(file2,"w")
       countChars = 0
       state = States.NORMAL
       
       for line in infile:
              for i in range(len(line)):
                     c = line[i]
                     if state == States.NORMAL:
                            state = handleNormal(c,outfile)                            

                     if state == States.IN_COMMENT:
                            state = handleInComment(c,outfile)

                     if state == States.IN_STR_LITERAL:
                            state = handleInStrLiteral(c,outfile)
       
                     if state == States.IN_CHAR_LITERAL:
                            state = handleInCharLiteral(c,outfile)
                            
                     if state == States.COMMENT_WAITING:
                            state = handleCommentWaiting(c,outfile)
                            
                     if state == States.ESCAPE_STR:
                            state = handleDoubleQEC(c,outfile)
                            
                     if state == States.ESCAPE_CHAR:
                            state = handleSingleQEC(c,outfile)
                            
                     if state == States.ESCAPE_WAITING:
                            state = handleEscapeWaiting(c,outfile)
                            
                     if state == States.OUT_OF_COMMENT_WAITING:
                           state = handleOOCW(c)
                            
    
       return file2
