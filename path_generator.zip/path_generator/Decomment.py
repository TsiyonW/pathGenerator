'''The program is to remove the comments incase there are
condition statements in the comment. And it works by switching
between states'''

class States:
       NORMAL = 'NORMAL'
       IN_COMMENT= 'IN_COMMENT'
       IN_STR_LITERAL = 'IN_STR_LITERAL'
       IN_CHAR_LITERAL = 'IN_CHAR_LITERAL'
       COMMENT_WAITING = 'COMMENT_WAITING'
       ESCAPE_STR = 'ESCAPE_STR'
       ESCAPE_CHAR = 'ESCAPE_CHAR'
       ESCAPE_WAITING = 'ESCAPE_WAITING'
       OUT_OF_COMMENT_WAITING = 'OUT_OF_COMMENT_WAITING'

def handleNormal(c,outfile):
    if c == '\'':
        outfile.write(c)
        state = States.IN_CHAR_LITERAL
        print(state)
    elif c == '\"':
        outfile.write(c)
        state = States.IN_STR_LITERAL
    elif c == '/':
        state = States.COMMENT_WAITING
    elif c == '\\':
        outfile.write(c)
        state = States.ESCAPE_WAITING
    elif c == '\n':
        outfile.write(c)
        state = States.NORMAL
    else:
        outfile.write(c)
        state = States.NORMAL
    

    return state

def handleInComment(c,outfile):
    if c == '*':
        state = States.OUT_OF_COMMENT_WAITING
        print(state)
    elif c == '\n':
        outfile.write(c)
        state = States.IN_COMMENT;
    else:
           outfile.write(" ")

    return state
def handleInStrLiteral(c,outfile):
    if c == '\n':
        outfile.write(c)
        state = States.IN_STR_LITERAL
        print(state)
    if c == '\"':

        state = States.NORMAL
    if c == '\\':
        state = States.ESCAPE_STR
    outfile.write(c)
    return state
def handleInCharLiteral(c,outfile):
    if c == '\n':
        state = States.IN_CHAR_LITERAL
        outfile.write(c)
        print(state)
    if c == '\'':
        state = States.NORMAL

    if c == '\\':
        state = States.ESCAPE_WAITING
    outfile.write(c)
    return state

def handleCommentWaiting(c,outfile):
    if c == '*':
        outfile.write(" ")
        state = States.IN_COMMENT
        print(state)
    
    else:
        outfile.write('/');
        outfile.write(c);
        state = States.NORMAL
    if c == '\n':
        outfile.write(c);

    return state

def handleDoubleQEC(c,outfile):
    if c == '\'':
        outfile.write(c);           
        state = States.IN_STR_LITERAL
        print(state)
    elif c == '\"':
        outfile.write(c);           
        state = States.IN_STR_LITERAL
    state = IN_STR_LITERAL
    if c == '\n':
       state = States.ESCAPE_STR
       outfile.write(c);
       
    return state

def handleSingleQEC(c,outfile):
    if c == '\'':
        outfile.write(c);
        state = States.IN_CHAR_LITERAL
        print(state)
    elif c == '\"':
        outfile.write(c);
        state = States.IN_CHAR_LITERAL
    state = IN_CHAR_LITERAL
    if c == '\n':
       outfile.write(c);
       state = States.ESCAPE_CHAR
       
    return state
def handleEscapeWaiting(c,outfile):
    if c == '\'':
        outfile.write(c);
        state = States.IN_NORMAL
        print(state)
    elif c == '\"':
        outfile.write(c);           
        state = States.IN_NORMAL

    elif c == '\n':
        outfile.write(c);           
        state = States.ESCPE_WAITING
    else:
        outfile.write(c);
    return state

def handleOOCW(c):
       if c =='/':
              state = States.NORMAL
       else:
              state = States.IN_COMMENT
       return state
    
def caller(file):
       array = []
       print(States.NORMAL)
       infile = open(file,"r")
       file2 = "Decommented_"+file
       outfile = open(file2,"w")
       countChars = 0
       state = States.NORMAL
       for line in infile:
              for i in range(len(line)):
                     c = line[i]
                     #switch between states
                     if state == States.NORMAL:
                            state = handleNormal(c,outfile)
                     if state == States.IN_COMMENT:
                            state = handleInComment(c,outfile)
                     if state == States.IN_STR_LITERAL:
                            state = handleInStrLiteral(c,outfile)
                     if state == States.IN_CHAR_LITERAL:
                            state = handleInCharLiteral(c,outfile)
                     if state == States.COMMENT_WAITING:
                            state = handleCommentWaiting(c,outfile)
                     if state == States.ESCAPE_STR:
                            state = handleDoubleQEC(c,outfile)
                     if state == States.ESCAPE_CHAR:
                            state = handleSingleQEC(c,outfile)
                     if state == States.ESCAPE_WAITING:
                            state = handleEscapeWaiting(c,outfile)
                     if state == States.OUT_OF_COMMENT_WAITING:
                            state = handleOOCW(c)
    
       return file2



















