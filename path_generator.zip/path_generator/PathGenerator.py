import Decomment as DEC
class States:
    NESTED = "NESTED"
    
def main():
    try:
        file = input("Enter a source file: ").strip()
        decommentedFile = DEC.caller(file) #remove the comment and get the new file





    except IOError:
        print("File "+f1+" doesnt exist")
