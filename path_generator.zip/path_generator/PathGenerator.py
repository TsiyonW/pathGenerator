''' BY TSIYON WULETAW ATR/0672/08  SE SECTION 2 '''
from enum import Enum
import stack as sk
'''
    The program parses a file(with methods) and generates a path where conditions flow
    but it works for programs that uses curly braces for opening and closing
    condition statements. for other programs that uses indentation produces false result
'''
class Flag:
    TRUE = 'T'
    FALSE = 'F'
class Status:
    NESTED = 'NESTED'
    NOT_NESTED = 'NOT NESTED'
class PathGenerator:
    def __init__(self):
            self.count = 0
            self.wIf = "if"
            self.wFor = "for"
            self.wWhile = "while"
            self.wElseif = "else if"
            self.wElif = "elif"
            self.wElse = "else"
            self.wCBr = "{"
            self.wCBl = "}"
            self.newLine = '\n'
            self.tab = '\t'
            self.myArray =[]
            self.paths = []
            self.noOfPath = 1
            self.pathNo =1
    #the method finds condition statements and appends to an array
    def parse(self,fileName):
        try:

            infile = open(fileName,"r")

            for line in infile:
                if self.wIf in line:
                    self.myArray.append(self.wIf)
                if self.wFor in line:
                    self.myArray.append(self.wFor)
                if self.wWhile in line:
                    self.myArray.append(self.wWhile)
                if self.wElseif in line:
                    self.myArray.append(self.wElseif)
                if self.wElif in line:
                    self.myArray.append(self.wElif)
                if self.wElse in line:
                    self.myArray.append(self.wElse)
                if self.wCBr in line:
                    self.myArray.append(self.wCBr)
                if self.wCBl in line:
                    self.myArray.append(self.wCBl)
                if self.newLine in line:
                    self.myArray.append(self.newLine)
                if self.tab in line:
                    self.myArray.append(self.tab)
                self.count += len(line)
            infile.close()
        
        except IOError:
            print("File "+f1+" doesnt exist")

        return self.myArray

    
    def generatePath(self):
        
            braceContainer = []         #will hold braces to know that the statement is nested or nt
            f1 = input("Enter a source file: ").strip()     #gets the filename
            myA = self.parse(f1)
            state = Status.NOT_NESTED
            for i in range(len(myA)):
                c = myA[i]
                if c == self.wElseif or c == self.wElif or c == self.wElse :    #if there is else, elseif or else there is an ifstatement so its nested
                    state = Status.NESTED
                if c == self.wFor or c == self.wWhile or c == self.wIf:
                    print(" is : "+myA[i])
                    if state == Status.NESTED:
                        self.handleNested(c)
                   
                    if state == Status.NOT_NESTED:
                        self.handleNotNested();

                if self.wCBr == myA[i]:
                    state = Status.NESTED
                    braceContainer.append(self.wCBr)    #stores { 
                if self.wCBl == myA[i]:                 #if } is found { will be poped out means the end of the first condition
                    if len(braceContainer) == 0:
                        state = Status.NOT_NESTED
                    else:
                        length = len(braceContainer)
                        braceContainer = braceContainer[1:]
                
                if len(braceContainer) == 0:
                    state = Status.NOT_NESTED
                
            state = Status.NOT_NESTED

    #appends the new paths on the previous ones
    def handleNested(self,c):
        a = self.paths
        n1 = []
        n2 = []
        if c == self.wElseif or c == self.wElif or c == self.wElse :
            n1 = a[len(a)-1]    #gets the previous path to append the new one on top of it
            n2 = a[len(a)-2]
        else:
            n1 = a[len(a)-2]
            n2 = a[len(a)-1]
            
        pathName1 = "path" + str(self.noOfPath)
        pathName1 = []
        pathName2 = []


        currentPath1 = str(self.pathNo) + "("+Flag.TRUE+")"
        currentPath2 = str(self.pathNo) + "("+Flag.FALSE+")"
        for i in range(len(n1)):
            pathName1.append(n1[i])
            pathName2.append(n1[i])
        pathName1.append(currentPath1)
        pathName2.append(currentPath2)
        a[len(a)-1]=pathName1
        a.append(pathName2)
            
        self.noOfPath = self.noOfPath + 1
        self.pathNo = self.pathNo + 1
    #appends the paths which is not nested to the array
    def handleNotNested(self):
        pathName1 = "path" + str(self.noOfPath)
        self.noOfPath = self.noOfPath + 1
        pathName2 = "path" + str(self.noOfPath)
        pathName1 = []
        pathName2 = []
        currentPath1 = str(self.pathNo) + "("+Flag.TRUE+")"
        currentPath2 = str(self.pathNo) + "("+Flag.FALSE+")"
        pathName1.append(currentPath1)
        pathName2.append(currentPath2)
        self.pathNo = self.pathNo + 1
        self.noOfPath = self.noOfPath + 1
        self.paths.append(pathName1)
        self.paths.append(pathName2)

    #prints the paths
    def printPath(self):
        a = self.paths
        for row in range(len(a)):
            print("path" + str(row+1), end = " : ")
            for col in range(len(a[row])):
                print(a[row][col], end = "  ")
            print()
def main():
    parse = PathGenerator()
    parse.generatePath()
    parse.printPath()
main()

