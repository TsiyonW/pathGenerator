import java.rmi.*;
// run independently (so has it's own main method)
public class Server{
    public static void main(String a[]) throws Exception{
        AddC obj = new AddC();
        // register the name using the caption name ADD to registry table
        Naming.rebind("ADD", obj);
        System.out.println("Server Started");
    }
}