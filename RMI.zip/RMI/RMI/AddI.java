import java.rmi.Remote;
// AddI will be a remote interface
public interface AddI extends Remote{ 

    public int add(int x, int y) throws Exception; // to handle exceptions
}